# train_model.py
import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.preprocessing import MinMaxScaler
import joblib

data = pd.read_csv(r"E:\72h\diabetes.csv")

# 预处理
cols_to_clean = ['Glucose', 'BloodPressure', 'SkinThickness', 'Insulin', 'BMI']
data[cols_to_clean] = data[cols_to_clean].replace(0, pd.NA)
data = data.dropna().drop_duplicates()

# 拆分数据
X = data.drop('Outcome', axis=1)
y = data['Outcome']

# 特征缩放
scaler = MinMaxScaler()
X[cols_to_clean] = scaler.fit_transform(X[cols_to_clean])

# 训练模型
model = RandomForestClassifier(n_estimators=100, max_features=int(len(X.columns)**0.5), random_state=42)
model.fit(X, y)

# 保存资源
joblib.dump(model, r"E:\72h\diabetes_model.pkl")
joblib.dump(scaler, r"E:\72h\scaler.pkl")