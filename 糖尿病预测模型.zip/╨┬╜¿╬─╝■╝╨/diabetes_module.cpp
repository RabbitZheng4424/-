#include <iostream>
#include <vector>
#include <sstream>
#include <cstdio>
#include <nlohmann/json.hpp>

using namespace std;
using json = nlohmann::json;

std::string execute_python(const std::vector<float>& data) {
    std::ostringstream cmd;
    cmd << "python script.py";
    for (auto val : data) cmd << " " << val;

    // 执行命令并获取输出
    FILE* pipe = popen(cmd.str().c_str(), "r");
    if (!pipe) {
        cerr << "无法执行命令" << endl;
        return "{}";
    }

    char buffer[128];
    std::string output;
    while (fgets(buffer, sizeof(buffer), pipe)) {
        output += buffer;
    }

    pclose(pipe);
    return output;
}

void display_result(const json& result) {
    if (result.contains("error") && !result["error"].is_null()) {
        std::wcerr << L"❌ 错误: "
                   << utf8_to_wstring(result["error"].get<std::string>())
                   << std::endl;
        return;
    }

    std::wcout << L"\n======== 糖尿病预测结果 ========\n"
               << L"诊断结论: "
               << (result["prediction"].get<int>() == 1 ? L"⚠️ 高风险" : L"✅ 低风险")
               << L"\n患病概率: "
               << result["probability"].get<double>() * 100 << L"%\n";

    // 修正tree_votes解析
    const auto& votes = result["tree_votes"];
    std::wcout << L"\n🌳 决策树投票:\n"
               << L"  安全票数: " << votes[0].get<int>() << L"\n"
               << L"  风险票数: " << votes[1].get<int>() << std::endl;

    // 特征重要性解析保持不变
    std::wcout << L"\n📊 关键影响因素分析:\n";
    std::vector<std::pair<std::string, double>> features;
    for (const auto& [key, value] : result["feature_importance"].items()) {
        features.emplace_back(key, value.get<double>());
    }

    std::sort(features.begin(), features.end(),
              [](const auto& a, const auto& b) { return a.second > b.second; });

    for (const auto& [name, importance] : features) {
        std::wcout << L"  " << utf8_to_wstring(name) << L": "
                   << importance * 100 << L"%" << std::endl;
    }
}