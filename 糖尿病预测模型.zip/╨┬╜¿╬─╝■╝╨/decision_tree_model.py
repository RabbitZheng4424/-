# -*- coding: utf-8 -*-
import sys
import json
import pandas as pd
import numpy as np
from sklearn.preprocessing import MinMaxScaler
from sklearn.ensemble import RandomForestClassifier
import joblib
from collections import Counter

# 常量定义
MODEL_PATH = r"E:\72h\diabetes_model.pkl"
SCALER_PATH = r"E:\72h\scaler.pkl"
DATA_PATH = r"E:\72h\diabetes.csv"

def load_resources():
    """加载预处理好的数据和模型"""
    data = pd.read_csv(DATA_PATH)
    scaler = joblib.load(SCALER_PATH)
    model = joblib.load(MODEL_PATH)
    return data, scaler, model

def predict(input_args):
    try:
        # 参数校验
        if len(input_args) != 8:
            raise ValueError("需要8个特征参数")

        # 转换输入
        features = list(map(float, input_args))

        # 加载资源
        data, scaler, model = load_resources()

        # 创建DataFrame
        new_data = pd.DataFrame([features], columns=data.columns[:-1])

        # 特征缩放
        cols_to_scale = ['Glucose', 'BloodPressure', 'SkinThickness', 'Insulin', 'BMI']
        new_data[cols_to_scale] = scaler.transform(new_data[cols_to_scale])

        # 预测
        prediction = int(model.predict(new_data)[0])  # 确保转换为int
        probability = float(model.predict_proba(new_data)[0][1])

        # 获取详细信息（关键修复点）
        tree_predictions = [int(tree.predict(new_data.values)[0]) for tree in model.estimators_]  # 转换为int
        votes = Counter(tree_predictions)
        tree_votes = {int(k): int(v) for k, v in votes.items()}  # 双重类型保证

        # 特征重要性
        feature_importance = dict(zip(data.columns[:-1], model.feature_importances_.tolist()))

        return {
            "prediction": prediction,
            "probability": probability,
            "tree_votes": tree_votes,
            "feature_importance": feature_importance,
            "error": None
        }

    except Exception as e:
        return {
            "error": str(e),
            "prediction": -1,
            "probability": 0.0,
            "tree_votes": {},
            "feature_importance": {}
        }

if __name__ == "__main__":
    # 命令行模式
    if len(sys.argv) == 9:
        result = predict(sys.argv[1:9])
        print(json.dumps(result, ensure_ascii=False, indent=2))
    else:
        print(json.dumps({"error": "参数数量错误"}, ensure_ascii=False, indent=2))