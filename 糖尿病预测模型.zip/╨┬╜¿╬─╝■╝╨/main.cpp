#include <iostream>
#include <vector>
#include <string>
#include <cstdio>
#include <io.h>
#include <fcntl.h>
#include <nlohmann/json.hpp>
#include <codecvt>
#include <locale>
#include <algorithm>
#include <cwchar>
#include <iomanip>
#include <filesystem>
#include <limits>

using json = nlohmann::json;
namespace fs = std::filesystem;

// =============== 前向声明 ===============
std::wstring utf8_to_wstring(const std::string& str);
void setup_console();
std::vector<float> get_user_input();
std::string execute_python_script(const std::vector<float>& input);
void display_result(const json& result);

// =============== 辅助函数实现 ===============
std::wstring utf8_to_wstring(const std::string& str) {
    std::wstring_convert<std::codecvt_utf8_utf16<wchar_t>> converter;
    return converter.from_bytes(str);
}

void setup_console() {
    _setmode(_fileno(stdout), _O_U8TEXT);
    _setmode(_fileno(stderr), _O_U8TEXT);
    system("chcp 65001 > nul");
}

// =============== 输入函数实现 ===============
std::vector<float> get_user_input() {
    std::vector<float> input_data;

    auto get_valid_input = [](const std::wstring& prompt,
                              float min_val,
                              float max_val) -> float {
        while(true) {
            std::wcout << prompt;
            float value;
            if(std::wcin >> value) {
                if(value >= min_val && value <= max_val) {
                    return value;
                }
                std::wcout << L"输入值需在 " << min_val << L" - " << max_val << L" 之间\n";
            } else {
                std::wcout << L"无效输入，请重新输入\n";
                std::wcin.clear();
                std::wcin.ignore(std::numeric_limits<std::streamsize>::max(), L'\n');
            }
        }
    };

    std::wcout << L"\n======== 请输入患者信息 ========\n";
    input_data.push_back(get_valid_input(L"怀孕次数 (0-20): ", 0, 20));
    input_data.push_back(get_valid_input(L"血糖 (20-300 mg/dL): ", 20, 300));
    input_data.push_back(get_valid_input(L"血压 (30-200 mmHg): ", 30, 200));
    input_data.push_back(get_valid_input(L"皮肤厚度 (0-99 mm): ", 0, 99));
    input_data.push_back(get_valid_input(L"胰岛素 (0-1000 μU/mL): ", 0, 1000));
    input_data.push_back(get_valid_input(L"BMI (10-60): ", 10, 60));
    input_data.push_back(get_valid_input(L"糖尿病遗传函数 (0.0-2.0): ", 0, 2));
    input_data.push_back(get_valid_input(L"年龄 (20-120): ", 20, 120));

    return input_data;
}

// =============== Python脚本执行函数 ===============
std::string execute_python_script(const std::vector<float>& input) {
    const std::wstring python_path = L"\"C:\\Program Files\\Python312\\python.exe\"";
    const std::wstring script_path = L"\"E:\\C++XiangMu\\decision_tree_model.py\"";

    std::wstring args;
    for (size_t i = 0; i < input.size(); ++i) {
        std::wostringstream tmp;
        if (input[i] == static_cast<int>(input[i])) {
            tmp << static_cast<int>(input[i]);
        } else {
            tmp << std::fixed << std::setprecision(4) << input[i];
            std::wstring num_str = tmp.str();
            num_str.erase(num_str.find_last_not_of(L'0') + 1, std::wstring::npos);
            if (!num_str.empty() && num_str.back() == L'.') {
                num_str.pop_back();
            }
        }
        args += L" " + tmp.str();
    }

    std::wstring full_cmd = L"cmd.exe /c \""
                            + python_path + L" "
                            + script_path
                            + args + L"\"";

    FILE* pipe = _wpopen(full_cmd.c_str(), L"r");
    if (!pipe) return R"({"error": "无法启动Python进程"})";

    char buffer[256];
    std::string result;
    while (fgets(buffer, sizeof(buffer), pipe) != nullptr) {
        result += buffer;
    }

    int status = _pclose(pipe);
    if (status != 0) {
        return R"({"error": "Python脚本执行失败（状态码：)" + std::to_string(status) + "\"}";
    }

    if (!result.empty() && result.back() == '\n') result.pop_back();
    return result.empty() ? R"({"error": "无有效输出"})" : result;
}

// =============== 结果显示函数 ===============
void display_result(const json& result) {
    if (result.contains("error") && !result["error"].is_null()) {
        std::wcerr << L"❌ 错误: " << utf8_to_wstring(result["error"].get<std::string>()) << std::endl;
        return;
    }

    std::wcout << L"\n======== 糖尿病预测结果 ========\n"
               << L"诊断结论: "
               << (result["prediction"].get<int>() == 1 ? L"\033[31m⚠️ 高风险\033[0m" : L"\033[32m✅ 低风险\033[0m")
               << L"\n患病概率: " << std::fixed << std::setprecision(1)
               << result["probability"].get<double>() * 100 << L"%\n";

    if (result.contains("tree_votes")) {
        const auto& votes = result["tree_votes"];
        std::wcout << L"\n🌳 决策树投票:\n"
                   << L"  安全票数: " << votes["0"].get<int>()
                   << L"\n  风险票数: " << votes["1"].get<int>();
    }

    if (result.contains("feature_importance")) {
        std::wcout << L"\n\n📊 关键影响因素分析:\n";
        std::vector<std::pair<std::string, double>> features;
        for (const auto& [key, value] : result["feature_importance"].items()) {
            features.emplace_back(key, value.get<double>());
        }

        std::sort(features.begin(), features.end(),
                  [](const auto& a, const auto& b) { return a.second > b.second; });

        for (const auto& [name, importance] : features) {
            std::wcout << L"  " << utf8_to_wstring(name) << L": "
                       << importance * 100 << L"%" << std::endl;
        }
    }
}

// =============== 主函数 ===============
int main() {
    setup_console();

    try {
        if (!fs::exists(L"E:\\72h\\diabetes_model.pkl")) {
            throw std::runtime_error("模型文件不存在");
        }

        std::vector<float> input_data = get_user_input();
        const std::string json_output = execute_python_script(input_data);

        json result = json::parse(json_output);

        std::wcout << L"\n======== 预测结果 ========\n";
        std::wstring conclusion = (result["prediction"].get<int>() == 1) ?
                                  L"\033[31m⚠️ 高风险（建议及时就医）\033[0m" :
                                  L"\033[32m✅ 低风险（保持健康作息）\033[0m";
        std::wcout << L"诊断结论: " << conclusion << L"\n";

        std::wcout << L"输入 'D' 查看详细信息，其他键退出: ";
        wchar_t choice;
        std::wcin >> choice;
        if(towupper(choice) == L'D') {
            display_result(result);
        }

    } catch (const std::exception& e) {
        std::wcerr << L"\n💥 系统异常: " << utf8_to_wstring(e.what()) << std::endl;
        return EXIT_FAILURE;
    }

    return EXIT_SUCCESS;
}