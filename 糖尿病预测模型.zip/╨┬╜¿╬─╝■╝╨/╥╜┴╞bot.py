import pandas as pd
import numpy as np
from sklearn.preprocessing import MinMaxScaler
#准备工具，导入数据三件套
data = pd.read_csv(r"E:\72h\diabetes.csv")
#从路径找到数据
print("原始数据前5行:\n", data.head())
#head（）观察前五行
print("缺失值情况:\n", data.isnull().sum())
#处理缺失值，isull()标记哪些是空的，统计共有多少排
cols_to_clean = ['Glucose', 'BloodPressure', 'SkinThickness', 'Insulin', 'BMI']
data[cols_to_clean] = data[cols_to_clean].replace(0, np.nan)
#这些值不可能是0，应该把这些关键指标换成NaN(空值）
print("处理0值后的缺失值情况:\n", data.isnull().sum())

data.fillna(data.mean(), inplace=True)
#计算平均的数值
data.drop_duplicates(inplace=True)
#发现并删除完全相同的行
scaler = MinMaxScaler()
data[cols_to_clean] = scaler.fit_transform(data[cols_to_clean])
#将指标缩放到0-1之间
data.to_csv("processed_diabetes.csv", index=False)
print("数据处理完成，已保存为 processed_diabetes.csv")
#不保留原来的编号，保存新的CSV文件
glucose_normalized = data['Glucose'].values
print("归一化后的前5个Glucose值:", glucose_normalized[:5])